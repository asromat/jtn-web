<!-- Scroll Nav Menu -->
<style>
    div.scrollmenu {
    overflow: auto;
    white-space: nowrap;
    height: 48px;
    margin: 0px;
    padding-bottom: 0pc;
    background-color: #f8f9fa;
    text-align: center;
}
div.scrollmenu a {
    display: inline-block;
    color: #5c5555;
    text-align: center;
    padding-left: 12px;
    padding-right: 12px;
    padding-top: 5px;
    padding-bottom: 0px;
    text-decoration: none;
    font-weight: 600;
}
    
</style>

<div class="scrollmenu">
    <a href="<?=base_url("kanal/agama")?>">Agama</a>
    <!-- <a href="<?=base_url("kanal/arema")?>">Arema</a> -->
    <!-- <a href="<?=base_url("kanal/citizen journalism")?>">Citizen Journalism</a> -->
    <a href="<?=base_url("kanal/ekonomi")?>">Ekonomi</a>
    <a href="<?=base_url("kanal/gaya hidup")?>">Gaya</a>
    <!-- <a href="<?=base_url("kanal/hiburan seni dan budaya")?>">Hiburan</a> -->
    <a href="<?=base_url("kanal/hukum dan kriminalitas")?>">Hukum dan Kriminalitas</a>
    <!-- <a href="<?=base_url("kanal/infograsi")?>">Inforgrafis MalangTIMES</a> -->
    <a href="<?=base_url("kanal/kesehatan")?>">Kesehatan</a>
    <a href="<?=base_url("kanal/kuliner")?>">Kuliner</a>
    <!-- <a href="<?=base_url("kanal/liputan khusus")?>">Lapsus</a> -->
    <a href="<?=base_url("kanal/olahraga")?>">Olahraga</a>
    <a href="<?=base_url("kanal/opini")?>">Opini</a>
    <a href="<?=base_url("kanal/otomotif")?>">Otomotif</a>
    <a href="<?=base_url("kanal/pemerintahan")?>">Pemerintahan</a>
    <a href="<?=base_url("kanal/pendidikan")?>">Pendidikan</a>
    <a href="<?=base_url("kanal/peristiwa")?>">Peristiwa</a>
    <a href="<?=base_url("kanal/politik")?>">Politik</a>
    <a href="<?=base_url("kanal/profil")?>">Profil</a>
    <!-- <a href="<?=base_url("kanal/riset")?>">Riset</a> -->
    <a href="<?=base_url("kanal/ruang mahasiswa")?>">Ruang Mahasiswa</a>
    <a href="<?=base_url("kanal/ruang sastra")?>">Ruang Sastra</a>
    <!-- <a href="<?=base_url("kanal/sejarah")?>">Sejarah</a> -->
    <a href="<?=base_url("kanal/selebriti")?>">Selebriti</a>
    <!-- <a href="<?=base_url("kanal/sertab-serbi")?>">Serba-serbi</a> -->
    <a href="<?=base_url("kanal/tekno")?>">Tekno</a>
    <!-- <a href="<?=base_url("kanal/times story")?>">Times Story</a> -->
    <a href="<?=base_url("kanal/transportasi")?>">Transportasi</a>
    <!-- <a href="<?=base_url("kanal/video")?>">Video</a> -->
    <a href="<?=base_url("kanal/wisata")?>">Wisata</a>
</div>
<!-- * Scroll Nav Menu -->