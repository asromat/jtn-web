<ul class="list-group">
    <li class="list-group-item bg-times text-white">
        <h1 class="mb-0 text-white text-uppercase lh-100 h6"><i class="fa fa-hashtag" aria-hidden="true"></i> Halaman</h1>
    </li>
    <li class="list-group-item"><a href="<?=base_url()?>tentang-kami">Tentang Kami</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>redaksi">Redaksi</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>info-iklan">Info Iklan</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>terms-of-use">Term of Use</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>standar-perlindungan-profesi-wartawan">Standar Perlindungan Profesi Wartawan</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>disclaimer">Disclaimer</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>pedoman-media-cyber">Pedoman Media Siber</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>privacy-policy">Privacy Policy</a></li>
    <li class="list-group-item"><a href="<?=base_url()?>legal-privacy">Kebijakan Data Pribadi</a></li>
</ul>