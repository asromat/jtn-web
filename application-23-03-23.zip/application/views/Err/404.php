<!-- App Capsule -->
<div id="appCapsule">
    <?php $this->view("element/main-nav-bar") ?>
    <!-- Row Iklan Panjang -->
    <div class="row mt-2">
        <div class="col-12">
            <div class="adbox adbox-responsive">
                <a href="<?= base_url()?>">
                    <img src="<?= base_url() ?>/assets/img/404.svg" alt="image">
                </a>
            </div>
        </div>
    </div>
    <!-- ! Row Iklan Panjang -->
</div>
<!-- * App Capsule -->