<div class="row mt-2">
    <div class="col-12">
        <div class="header-large-title">
        </div>
        <div class="card-body">
            <div class="carousel-single owl-carousel owl-theme owl-loaded owl-drag">
                <div class="owl-stage-outer">
                    <div class="owl-stage" style="transform: translate3d(-1033px, 0px, 0px); transition: all 0s ease 0s; width: 3161px; padding-left: 30px; padding-right: 30px;">
                    
                        <div class="owl-item" style="width: 328.533px; margin-right: 16px;">
                            <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads1']?>"></script>
                            </div>
                             <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads2']?>"></script>
                            </div>
                             <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads3']?>"></script>
                            </div>
                             <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads4']?>"></script>
                            </div>
                             <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads5']?>"></script>
                            </div>
                             <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads6']?>"></script>
                            </div>
                             <div class="item">
                                <script src="https://pasangiklan.jatimtimes.com/amb/ser.php?f=<?=$daerah['ads7']?>"></script>
                            </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>