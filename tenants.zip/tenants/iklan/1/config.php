<?php

$data['ads1'] = "1";
$data['ads2'] = "1";
$data['ads3'] = "1";
$data['ads4'] = "1";
$data['ads5'] = "1";
$data['ads6'] = "1";
$data['ads7'] = "1";
$data['ads8'] = "1";
$data['ads9'] = "1";
$data['ads10'] = "1";
$data['ads11'] = "1";
$data['ads12'] = "1";
$data['ads13'] = "1";
$data['ads14'] = "1";
$data['ads15'] = "1";
$data['ads16'] = "1";
$data['ads17'] = "1";
$data['ads18'] = "1";
$data['ads19'] = "1";
$data['ads20'] = "1";

return $data;