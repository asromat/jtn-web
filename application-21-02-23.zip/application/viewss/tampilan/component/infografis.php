<div class="row mt-2">
    <div class="col-12">
        <div class="header-large-title bg-times-gradient">
            <h1 class="title">#Infografis</h1>
            <h4 class="subtitle">Nikmati Baca Berita dengan Visual</h4>
        </div>
        <div class="card-body">
            <div class="carousel-single owl-carousel owl-theme owl-loaded owl-drag">
                <div class="owl-stage-outer">
                    <div class="owl-stage" style="transform: translate3d(-1033px, 0px, 0px); transition: all 0s ease 0s; width: 3161px; padding-left: 30px; padding-right: 30px;">
                        <div class="owl-item" style="width: 328.533px; margin-right: 16px;">
                            <div class="item">
                                <img src="https://risetcdn.jatimtimes.com/images/2022/10/10/security-officer-arema-fc-pintu-stadion-kanjuruhan-04-04061b286413f7c819.md.png" alt="alt" class="imaged w-100">
                            </div>
                        </div>
                        <div class="owl-item" style="width: 328.533px; margin-right: 16px;">
                            <div class="item">
                                <img src="https://risetcdn.jatimtimes.com/images/2022/10/10/korban-tragedi-kanjuruhan-menghitam-04139e59ff8270e42f.md.png" alt="alt" class="imaged w-100">
                            </div>
                        </div>
                        <div class="owl-item" style="width: 328.533px; margin-right: 16px;">
                            <div class="item">
                                <img src="https://risetcdn.jatimtimes.com/images/2022/10/10/uin-maliki-malang-prestasi-mahasiswa-perbankan-syariah-02215fafa6ca6c5716.md.png" alt="alt" class="imaged w-100">
                            </div>
                        </div>
                        <div class="owl-item" style="width: 328.533px; margin-right: 16px;">
                            <div class="item">
                                <img src="https://risetcdn.jatimtimes.com/images/2022/10/09/rektor-uin-maliki-malang-03322ca34e452bc731.md.png" alt="alt" class="imaged w-100">
                            </div>
                        </div>
                        <div class="owl-item" style="width: 328.533px; margin-right: 16px;">
                            <div class="item">
                                <img src="https://risetcdn.jatimtimes.com/images/2022/10/09/uin-malang-tragedi-kanjuruhan-021a67e8165f9585a6.md.png" alt="alt" class="imaged w-100">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>