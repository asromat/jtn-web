<meta property="fb:app_id" content="621270734944156" />
<meta property="fb:admins" content="114477503528250" />
<meta property="og:locale" content="id_ID" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Surabaya Times" />
<meta property="og:description" content=" Jatim TIMES Media Online Mainstream Pertama di Jawa Timur, menyajikan info berita Jawa Timur yang membangun, menginspirasi, dan berpositif thinking berdasarkan jurnalisme positif." />
<meta property="og:url" content=" https://jatimtimes.com " />
<meta property="og:site_name" content="Jatim TIMES" />
<meta property="og:image" itemprop="image" content=" " />
<meta property="og:image:secure_url" itemprop="image" content=" " />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="315" />
<meta property="og:ttl" content="2419200" />
<script async src="https://cdn.jsdelivr.net/npm/lazyhtml@1.2.3/dist/lazyhtml.min.js" crossorigin="anonymous"></script>
<meta property="article:tag" content=" jatim times,Jawa Timur times,info berita Jawa Timur hari ini,berita terbaru Jawa Timur" />
<meta name="keywords" content="jatim times,Jawa Timur times,info berita Jawa Timur hari ini,berita terbaru Jawa Timur" />
<meta name="description" content=" Media Online Mainstream Pertama di Jawa Timur, menyajikan info berita Jawa Timur yang membangun, menginspirasi, dan berpositif thinking berdasarkan jurnalisme positif. " />
<meta name="csrf-token" content="xTqORKaQfmONhqjSh9QFFpkYBy5bRU7DvPN6QDF2">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Cache-Control" content="public" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="2022-12-11 09:53:08" />
<meta http-equiv="last-modified" content="2022-12-11 09:53:08" />
<meta name="generator" content="Jatim TIMES 1.1">
<meta property="article:publisher" content="https://www.facebook.com/jatimtimes" />
<meta property="article:author" content="https://www.facebook.com/jatimtimes" />
<meta name="subject" content="News, Media">
<meta name="copyright" content="Jatim TIMES">
<meta name="robots" content="index,follow">
<meta name="googlebot-news" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="city" content="Jawa Timur">
<meta name="country" content="Indonesia">

<meta name="alexaVerifyID" content="hgYpu1hNdI20fn" />
<meta name="yandex-verification" content="" />
<meta name="msvalidate.01" content="" />
<meta name="google-site-verification" content="UA-81618725-1" />
<meta name="revisit-after" content="7" />
<meta name="webcrawlers" content="all" />
<meta name="rating" content="general" />
<meta name="spiders" content="all" />
<meta name="robots" content="all" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta itemprop="name" content=" Jatim TIMES: Media Online Mainstream Pertama di Jawa Timur ">
<meta itemprop="description" content=" Jatim TIMESMedia Online Mainstream Pertama di Jawa Timur, menyajikan info berita Jawa Timur yang membangun, menginspirasi, dan berpositif thinking berdasarkan jurnalisme positif. ">
<meta itemprop="image" content=" ">

<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@JatimTIMES">
<meta name="twitter:title" content=" Jatim TIMES: Media Online Mainstream Pertama di Jawa Timur ">
<meta name="twitter:description" content=" Jatim TIMES Media Online Mainstream Pertama di Jawa Timur, menyajikan info berita Jawa Timur yang membangun, menginspirasi, dan berpositif thinking berdasarkan jurnalisme positif. ">
<meta name="twitter:creator" content="@JatimTIMES">
<meta name="twitter:image" content=" ">
<meta name='dailymotion-domain-verification' content="" />
<meta property="dable:item_id" content="2015111202028">
<link href="//jsc.mgid.com" rel="dns-prefetch">
<link href="//risetcdn.jatimtimes.com" rel="dns-prefetch">
<link href="//jatimtimes.com" rel="dns-prefetch">
<link rel="dns-prefetch" href="//adservice.google.com/">
<link rel="dns-prefetch" href="//googleads.g.doubleclick.net/">
<link rel="dns-prefetch" href="//www.googletagservices.com/">
<link rel="dns-prefetch" href="//tpc.googlesyndication.com/">

<link rel="dns-prefetch" href="//ajax.googleapis.com">

<link rel="dns-prefetch" href="//apis.google.com">

<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//fonts.gstatic.com">

<link rel="dns-prefetch" href="//www.google-analytics.com">

<link rel="dns-prefetch" href="//www.googletagmanager.com">

<link rel="dns-prefetch" href="//www.googletagservices.com">

<link rel="dns-prefetch" href="//pagead2.googlesyndication.com">

<link rel="dns-prefetch" href="//cdnjs.cloudflare.com">

<link rel="dns-prefetch" href="//code.jquery.com">

<link rel="dns-prefetch" href="//connect.facebook.net">

<link rel="dns-prefetch" href="//platform.twitter.com">
<link rel="canonical" href="https://jatimtimes.com/">
<link rel="alternate" href="https://jatimtimes.com/" hreflang="id-id" />

<link rel="shortcut icon" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" sizes="57x57" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="60x60" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="72x72" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="76x76" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="114x114" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="120x120" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="144x144" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="152x152" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="apple-touch-icon" sizes="180x180" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="icon" type="image/png" sizes="192x192" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="icon" type="image/png" sizes="96x96" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">
<link rel="icon" type="image/png" sizes="16x16" href="https://jatimtimes.com/v3/assets/img/logo/favicon.ico">

<link rel="alternate" type="application/rss+xml" title="Jatim TIMES Feed" href="https://jatimtimes.com/feed.xml" />
<link rel="mask-icon" href="https://jatimtimes.com/v3/assets/img/favicon/safari-pinned-tab.svg" color="#2196f3">
<meta name="msapplication-config" content="https://jatimtimes.com/v3/assets/img/favicon/browserconfig.xml">
<meta name="msapplication-TileImage" content="https://jatimtimes.com/v3/assets/img/favicon/ms-icon-144x144.png">
<meta name="msapplication-TileColor" content="#2196f3">
<meta name="theme-color" content="#ffffff">